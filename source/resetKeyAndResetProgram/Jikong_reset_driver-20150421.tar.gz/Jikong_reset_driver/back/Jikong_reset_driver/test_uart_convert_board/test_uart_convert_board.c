#include <stdio.h>      
#include <stdlib.h>    
#include <unistd.h>    
#include <sys/types.h>  
#include <sys/stat.h>  
#include <fcntl.h>    
#include <termios.h>    
#include <errno.h> 
#include <string.h>
#include <linux/reboot.h>
#include <sys/reboot.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include <errno.h>
#include <time.h>

#define FNAME	"/var/out"

static char *device_name[]={"/dev/Jikong_study_Led_v2","/dev/Jikong_UART_Reset","/dev/Jikong_irDA_study"};

#define CONFIG_NAME		"config.ini"
#define CONFIG_DEF		"default.ini"

#define STRSIZE 1024
#define BUF_SIZE		1024
static int cp_config(char *src, char * des)
{
	int sfd, dfd;
	int cou;
	char buffer[BUF_SIZE];

	if(src == NULL || des == NULL)
		return -1;

	sfd = open(src, O_RDONLY);
	if(sfd < 0) {
		perror("open src");	
		return -1;
	}
	dfd = open(des, O_TRUNC | O_CREAT | O_WRONLY, 444);
	if(dfd < 0) {
		perror("open des");	
		return -1;
	}

	while(1)
	{
		if((cou = read(sfd, buffer, BUF_SIZE)) < 0) {
			perror("read");	
			return -1;
		}	

		if(cou == 0) {
			close(sfd);
			close(dfd);
			return 0;		
		}

		if(write(dfd, buffer, cou) < 0) {
			perror("write");	
			return -1;
		}
	}

	close(sfd);
	close(dfd);
	return 0;
}
static int  daemonize(void)
{
	int fd;
	pid_t pid;

	pid = fork();
	if(pid < 0)
		return -1;

	if(pid > 0)
		exit(0);
	
	fd = open("/dev/null",O_RDWR);
	if(fd < 0)
	{
		return -2;
	}	

	dup2(fd,0);
	dup2(fd,1);
	dup2(fd,2);
	if(fd > 2)
		close(fd);

	setsid();

	chdir("/");
//	umask(0);
	
	return 0;
}

static void my_reboot()
{
	if(reboot(LINUX_REBOOT_CMD_RESTART) != 0) {
		perror("reboot");	
		return ;
	}
}


int main(void)
{
	FILE *fp;
	int i=0,j=0,ret=0;
	char buffer[10];
	memset(buffer,0,10);
	//scanf("%d",&i);
	time_t stamp;
	struct tm *tm;
	char timestr[STRSIZE];
	char fmt[STRSIZE] = {'\0'};	
	FILE *fpd = stdout;

	i=1;
	int fd = open(device_name[i],O_RDWR);//270
	if(fd<0)
	{
		printf("Can not Open %s device !\n",device_name[i]);
		return 0;
	}
	
	/* open syslog*/
	openlog("mydaemon",LOG_PID,LOG_DAEMON);

	if(daemonize())
	{
		syslog(LOG_ERR,"daemonize() failed!");
		exit(1);
	}
	else
		syslog(LOG_INFO,"daemonize() successed!");

	fp = fopen(FNAME,"a");
	if(fp == NULL)
	{
		syslog(LOG_ERR,"fopen():%s",strerror(errno));
		exit(1);
	}
	
	syslog(LOG_INFO,"%s was opened.",FNAME);
	/* open syslog success*/

	/* get time*/
	stamp = time(NULL);
	tm = localtime(&stamp);

	strftime(timestr,STRSIZE, "%x\t%X",tm);
	/* success get time*/
	
	while(1) 
	{
		switch (i)
		{
		case 0:
			printf("0:red light\n");
			printf("1:yellow light\n");
			printf("please input light color:");
			scanf("%d",&j);
			if (0 != j)
				j=1;
			buffer[0] = j;
			write(fd,buffer,1);
			break;
		case 1:
			memset(buffer,0,10);
			ret = read(fd,buffer,10);
			
			//buffer[ret] = '1';
			//buffer[ret+1] = '\0';
			fprintf(fp, "interrupt retun value:\t%d\t%s\n", ret, timestr);
			cp_config(CONFIG_DEF, CONFIG_NAME);
			sync();
			fclose(fp);
			closelog();
			my_reboot();

			break;
		case 2:
			sleep(1000);
			break;
		default:
			printf("0:red light\n");
			printf("1:green light\n");
			printf("please input light color:");
			scanf("%d",&j);
			if (0 == j)
				j=1;
			write(fd,j,1);
			break;
		}


	}
return 0;
}	
