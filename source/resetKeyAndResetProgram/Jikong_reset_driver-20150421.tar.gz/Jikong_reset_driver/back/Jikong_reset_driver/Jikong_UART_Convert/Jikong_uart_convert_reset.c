#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/module.h>
//#include <asm/io.h>
#include <linux/miscdevice.h>
#include <linux/ioctl.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>
#include <linux/poll.h>
#include <linux/interrupt.h>
#include <linux/errno.h>
#include <linux/io.h>
#include <linux/cdev.h>
#include <plat/gpio-cfg.h>
#include <plat/regs-gpio.h>
#include <mach/gpio.h>
#include <mach/regs-mem.h>

#define DEBUG0 	      0
#define JIKONG_MAX_DEVS 1
#define JIKONG_DEV_NAME "Jikong_UART_Reset"
#define JIKONG_CLS_NAME "Jikong_UART_Convert_Reset"

#define STATUS_NOKEY 0    //无按键状态，按键抬起
#define STATUS_DOWNX 1    //有按键状态，但不确定
#define STATUS_DOWN  2    //等释放状态，确定按下
#define STATUS_DOWN_RET  3    //设置返回状态，在按下一段时间后返回值



static dev_t JIKONG_base_id;
static int cur_dev_num = 1;
static int wait_seconds = 0;
static struct class* JIKONG_class;



typedef struct JIKONG_dev {
	dev_t dev_id;
	struct cdev chrdev;
	unsigned int dev_idx;
	wait_queue_head_t wq;
	unsigned int key_Status; 	  //按键状态
	struct timer_list key_timer;	  //按键去抖定时器
}JIKONG_dev_t;

static JIKONG_dev_t* JIKONG_devs[JIKONG_MAX_DEVS];

static void key_timer_handler(unsigned long data);
static irqreturn_t JIKONG_isr(int irq,void *dev_id);
static int __devinit JIKONG_probe(struct platform_device *pdev);
static int __devexit JIKONG_remove(struct platform_device *pdev);
static int JIKONG_open(struct inode *inode, struct file *filp);
static int JIKONG_close(struct inode *inode, struct file *filp);
static int JIKONG_read(struct file *filp,
			char *buff, 
			size_t count, loff_t *offp);




/*
timer function
*/
static void key_timer_handler(unsigned long data)
{
	JIKONG_dev_t *Fdev;
	Fdev = (JIKONG_dev_t *)data;
	if (Fdev == NULL)
	{
		printk("No device!!!\n");
		return;

	}

	if( !(readl(S3C64XX_GPNDAT) & (0x1 << 2))) //键抬起   
	{    
		wait_seconds = 0;
		Fdev->key_Status=STATUS_NOKEY;
		
		writel( 0x1 << 2 ,S3C64XX_EINT0PEND);
		writel((readl(S3C64XX_GPNCON) & ~(0x3 << 4)) | (0x2 << 4), S3C64XX_GPNCON);//重新配置GPI0为中断模式
	}
	else{        //仍处于按下状态

		if(Fdev->key_Status==STATUS_DOWNX)    //从中断进入
		{  
			Fdev->key_Status=STATUS_DOWN; 
			Fdev->key_timer.expires=jiffies+HZ/5;//延迟200毫秒
			add_timer(&Fdev->key_timer);
		}
		else				      //keyStatus=STATUS_DOWN
		{   			      
			Fdev->key_timer.expires=jiffies+HZ/5;//延迟200毫秒
			if (Fdev->key_Status==STATUS_DOWN) 
			{
				wait_seconds++;
				if (wait_seconds >= 35)// 7 seconds
				{
				Fdev->key_Status=STATUS_DOWN_RET;
				}
			}
			else if(Fdev->key_Status==STATUS_DOWN_RET)
			{
				wake_up_interruptible(&Fdev->wq);
			}

			add_timer(&Fdev->key_timer);
		}
	}


}

/*
interrupt service function
*/
static irqreturn_t JIKONG_isr(int irq,void *dev_id)
{

	JIKONG_dev_t *Fdev = (JIKONG_dev_t *)dev_id;
	if (Fdev == NULL) 
	{
		printk("No device!!!\n");
		goto out;
	}
	writel((readl(S3C64XX_GPNCON) & ~(0x3 << 4)) | (0x0 << 4), S3C64XX_GPNCON);//set input pin

	Fdev->key_Status=STATUS_DOWNX;		    //转为DOWNX，不确定状态
	Fdev->key_timer.expires=jiffies+HZ/50;       //延迟20ms
	add_timer(&Fdev->key_timer);    	        //启动定时器
	//屏蔽等待中断，数据都已经读完
	writel( 0x1 << 2 ,S3C64XX_EINT0PEND);
	
out:	
	return IRQ_HANDLED;


}


static int JIKONG_open(struct inode *inode, struct file *filp)
{
	JIKONG_dev_t* Fdev;
	int idx;
	idx = iminor(inode) - MINOR(JIKONG_base_id);
	Fdev = JIKONG_devs[idx];
	wait_seconds = 0;
	filp->private_data = Fdev;
	return 0;
}

static int JIKONG_close(struct inode *inode, struct file *filp)
{
	JIKONG_dev_t* Fdev;
	int idx;
	idx = iminor(inode) - MINOR(JIKONG_base_id);
	Fdev = JIKONG_devs[idx];
	filp->private_data = NULL;
	printk("JIKONG reset,bye %d\n", Fdev->dev_idx);
	return 0;
}

static int JIKONG_read(struct file *filp,
			char *buff, 
			size_t count, loff_t *offp)
{
	int ret = 0;
	char *b = buff;
	char temp_buff[1];
	JIKONG_dev_t *Fdev = filp->private_data;

	if(filp->f_flags & O_NONBLOCK)    //若用户采用非阻塞方式读取
		return -EAGAIN;
	
	interruptible_sleep_on(&Fdev->wq);
	if (Fdev->key_Status==STATUS_DOWN_RET)
	{
	temp_buff[0] = '1';
	}
	else
	{
	temp_buff[0] = '0';
	}
	
	ret = copy_to_user(buff,(char *)&temp_buff,1);

	wait_seconds = 0;
		
	return 1;
}


static struct platform_driver JIKONG_driver = {
	.probe = JIKONG_probe,
	.remove = JIKONG_remove,
	.driver = {
	   .name = "Jikong_UART_Convert_Reset",
	   .owner = THIS_MODULE,
	},
};

static struct file_operations JIKONG_fops = {
	.owner = THIS_MODULE,
	.open = JIKONG_open,
	.release = JIKONG_close,
	.read = JIKONG_read,
};

static int __devinit JIKONG_probe(struct platform_device *pdev)
{
	int ret;
	
	struct class_device *cls_dev;
	JIKONG_dev_t *Fdev;

	//------------get resources from mach-smdk6410.c---------------
	JIKONG_devs[cur_dev_num] = Fdev = kzalloc(sizeof(JIKONG_dev_t), GFP_KERNEL);
	if (Fdev == NULL) {
		dev_err(&pdev->dev, "no memory for device data\n");
		ret = -ENOMEM;
		goto err1;
	}
	
        
       /*----------------create device-----------------------
	   alloc devid
	   add character device
	   create device
	*/
	Fdev->dev_idx = cur_dev_num++;
	Fdev->dev_id = MKDEV(MAJOR(JIKONG_base_id), MINOR(JIKONG_base_id) + Fdev->dev_idx);
	pdev->dev.devt = Fdev->dev_id;
	cdev_init(&Fdev->chrdev, &JIKONG_fops);
	Fdev->chrdev.owner = THIS_MODULE;
	ret = cdev_add(&Fdev->chrdev, Fdev->dev_id, 1);
	if (ret){
	   printk("fail to register driver for " JIKONG_DEV_NAME "!\n", pdev->id);
	   goto err1;
	}
	
	
	platform_set_drvdata(pdev, Fdev);
	cls_dev = device_create(JIKONG_class,NULL, Fdev->dev_id, &pdev->dev, 
				JIKONG_DEV_NAME, Fdev->dev_idx);
	if (IS_ERR(cls_dev))
		goto err_cls;
        
	
	writel((readl(S3C64XX_GPNCON) & ~(0x3 << 4)) | (0x2 << 4), S3C64XX_GPNCON);
	writel(readl(S3C64XX_GPNPUD) & ~(0x3 << 4), S3C64XX_GPNPUD);

 	writel((readl(S3C64XX_EINT0CON0) & ~(0x7 <<4)) | (0x1 << 4),
		S3C64XX_EINT0CON0);		
	
	writel(0x1 << 2,S3C64XX_EINT0PEND);	
	writel(readl(S3C64XX_EINT0MASK) | (0x1 << 2), S3C64XX_EINT0MASK);
	

	Fdev->key_Status=STATUS_NOKEY;//初始化按键状态
	//初始化定时器，实现软件去抖
	init_timer(&Fdev->key_timer);
	Fdev->key_timer.data = (unsigned long)Fdev;
	Fdev->key_timer.function=key_timer_handler;
	Fdev->key_timer.expires = 0;

	ret=request_irq(S3C_EINT(2),(void *)&JIKONG_isr,
					IRQF_SHARED,
					"Jikong_UART_Convert_Reset",(void *)Fdev);
        
	init_waitqueue_head(&Fdev->wq);

	

	printk("driver for "JIKONG_DEV_NAME".%d (%d,%d) registered\n", 
		Fdev->dev_idx, MAJOR(Fdev->dev_id), MINOR(Fdev->dev_id));
	return ret;


 err_res:
	kfree(Fdev);
 err1:
	return ret;
 err_cls:
	return PTR_ERR(cls_dev);
 
}

static int __devexit JIKONG_remove(struct platform_device *pdev)
{
	JIKONG_dev_t* Fdev;
	
	device_destroy(JIKONG_class, pdev->dev.devt);
	Fdev = platform_get_drvdata(pdev);
	if (Fdev) cdev_del(&Fdev->chrdev);
	
	free_irq(S3C_EINT(2),(void *)Fdev);
	kfree(Fdev);
	platform_set_drvdata(pdev, NULL);
	pdev->dev.devt = 0;
	cur_dev_num--;
	printk(JIKONG_CLS_NAME "%d removed!\n", pdev->id);

	return 0;
}




static int __init JIKONG_init(void)
{ 

	int ret;
	cur_dev_num = 1;
	ret = alloc_chrdev_region(&JIKONG_base_id, 0,JIKONG_MAX_DEVS,JIKONG_CLS_NAME);
	if (ret)
	   return ret;

	JIKONG_class = class_create(THIS_MODULE, JIKONG_CLS_NAME);
	if (IS_ERR(JIKONG_class))
	   return PTR_ERR(JIKONG_class);

	ret = platform_driver_register(&JIKONG_driver);
	return ret;
}

static void __exit JIKONG_exit(void)
{
	
	platform_driver_unregister(&JIKONG_driver);
	class_destroy(JIKONG_class);
	unregister_chrdev_region(JIKONG_base_id, JIKONG_MAX_DEVS);
	printk("unregister driver " JIKONG_CLS_NAME "\n");
}

module_init(JIKONG_init);
module_exit(JIKONG_exit);
MODULE_LICENSE("GPL");

 
