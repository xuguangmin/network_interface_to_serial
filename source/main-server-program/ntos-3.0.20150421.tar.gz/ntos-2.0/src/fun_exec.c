#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "fun_exec.h"
#include "./sqlite_lib/include/sqlite3.h"

sqlite3 *g_dbConfig      = NULL;
/*
 * 表的初始值
 * 纵向排列，以关键字识别每一行
 * 如果要在表中增加行，在这儿增加
*/
struct __db_table_cfg_value_init db_table_cfg_value_init[] = { 
	{ SQLITE_NAME_DEV_NAME,        "PHILISENSE_NETWORT_SERIAL" },
	{ SQLITE_NAME_DEVICE_ID,       "1" },
	{ SQLITE_NAME_VERSION,         "2.0" },
	{ SQLITE_NAME_SERIAL_1,        "串口1" },
	{ SQLITE_NAME_SERIAL_2,        "串口2" },
	{ SQLITE_NAME_SERIAL_3,        "串口3" },
	{ SQLITE_NAME_SERIAL_4,        "串口4" },
	{ SQLITE_NAME_RATE_1,          "115200" },
	{ SQLITE_NAME_RATE_2,          "115200" },
	{ SQLITE_NAME_RATE_3,          "115200" },
	{ SQLITE_NAME_RATE_4,          "115200" },
	{ SQLITE_NAME_DATA_1,          "8" },
	{ SQLITE_NAME_DATA_2,          "8" },
	{ SQLITE_NAME_DATA_3,          "8" },
	{ SQLITE_NAME_DATA_4,          "8" },
	{ SQLITE_NAME_STOP_1,          "N" },
	{ SQLITE_NAME_STOP_2,          "N" },
	{ SQLITE_NAME_STOP_3,          "N" },
	{ SQLITE_NAME_STOP_4,          "N" },
	{ SQLITE_NAME_PARITY_1,        "1" },
	{ SQLITE_NAME_PARITY_2,        "1" },
	{ SQLITE_NAME_PARITY_3,        "1" },
	{ SQLITE_NAME_PARITY_4,        "1" },
	{ SQLITE_NAME_WORK_MODE,       "1" },
	{ SQLITE_NAME_IP       ,       "192.168.1.101" },
	{ SQLITE_NAME_MASK,            "255.255.255.0" },
	{ SQLITE_NAME_SERPORT_1,       "5050" },
	{ SQLITE_NAME_SERPORT_2,       "5051" },
	{ SQLITE_NAME_SERPORT_3,       "5052" },
	{ SQLITE_NAME_SERPORT_4,       "5053" },
	{ SQLITE_NAME_GATEWAY  ,       "192.168.1.1" },
	{ SQLITE_NAME_REG_IP  ,        "192.168.1.100" },
	{ SQLITE_NAME_REGPORT ,        "9000" },
	{ SQLITE_NAME_PASSWD  ,        "admin" },
	{"END", "END" }
};

struct __db_table_main_rec db_table_main_rec;
/*
 * 修改value
 *
 * 修改数据库中sysinfo表中的value字段
 * name字段是参数名的标识，对应于参数id
 * 参数：
 *      id        对应于页分类name
 *      filename  对应于字段value
 * 返回值：1成功，否则失败
 */
int modify_table_value(sqlite3* sqlite, const char *name, char *value)
{
	char sql_string[256];
	char *pErrMsg = NULL;

	sprintf(sql_string, "update %s set value = '%s' where name ='%s'", NTOS_TABLE_SYSINFO, value, name);
	printf("sql:'%s'\r\n", sql_string);
	if(sqlite3_exec(sqlite, sql_string, 0, 0, &pErrMsg) != SQLITE_OK)
	{
		fprintf(stderr,"modify_res_file_name SQL is failed : %s\n", sql_string);
		return 0;
	}

	if(pErrMsg != NULL)
		sqlite3_free(pErrMsg);

	return 1;
}

/* 修改记录的值 */
static int db_table_main_load_set(const char *key_name, const char *new_value)
{
	int k;
	if(!key_name || !new_value || strlen(key_name) <= 0 || strlen(new_value) <= 0)
		return 0;

	for(k = 0; ;k++)
	{
		if(!strcmp(db_table_cfg_value_init[k].key_name, "END"))
			break;

		if(!strcasecmp(db_table_cfg_value_init[k].key_name, key_name))
		{
			strcpy(db_table_cfg_value_init[k].value, new_value);
			return 1;
		}
	}
	return 0;
}
static int sqlite_callback_cfg_info(void *data,int col_count,char **col_values,char **col_name)
{
	int k;
	db_table_main_rec.key_name[0] = '\0';
	db_table_main_rec.value[0] = '\0';

	for(k = 0; k < col_count; ++k)
	{
		if(!strcasecmp(col_name[k], TABLE_MAIN_COL_KEY)){ 
			strncpy(db_table_main_rec.key_name, col_values[k], 100-1);
		}
		else if(!strcasecmp(col_name[k], TABLE_MAIN_COL_VALUE)) {
			strncpy(db_table_main_rec.value, col_values[k], 100-1);
		}
	}

	//printf("%s = %s\r\n", db_table_main_rec.key_name, db_table_main_rec.value);
	db_table_main_load_set(db_table_main_rec.key_name, db_table_main_rec.value);
	return 0;
}
/*
 * 从数据库中取配置信息
 *
 * 返回值：1成功，否则失败
 */
int db_table_main_load(sqlite3 *db, const char *tab_name)
{
	char *pErrMsg = NULL;
	char sqlstr[512];

	sprintf(sqlstr, "select *from %s", tab_name);
	//sprintf(sqlstr, "create table contacts (id integer primary key, name text);", tab_name);
	if(sqlite3_exec(db, sqlstr, sqlite_callback_cfg_info, NULL, &pErrMsg) != SQLITE_OK) {
		fprintf(stdout, "%s\n", pErrMsg);
		return 0;
	}

	return 1;
}
char* get_datastr(struct __db_table_cfg_value_init *data, char *key, char *buf)
{
	int i;

	if(data == NULL || key == NULL)
		return NULL;

	for(i = 0; strcmp(data->key_name, "END") != 0; i++) {
		if(i > 34) {
			printf("%d iii  %s\r\n", i, data[i].key_name);
			return NULL;
		}
		if(!strcasecmp(data[i].key_name, key)) {
			strcpy(buf, data[i].value);
			return data[i].value;
		}
	}

	return NULL;
}

//-------------------- get config data ---------------------------
int get_sqlite_serial(int serno, serial_t *serdata)
{
	char buf[64];
	int *speed, *data, *stop, *parity;

	if(serdata == NULL)
		return EFAILED;


	speed  = &(serdata->speed);
	data   = &(serdata->data);
	stop   = &(serdata->stop);
	parity = &(serdata->parity);

	*speed  = -1;
	*data   = -1;
	*stop   = -1;
	*parity = -1;

	switch(serno)
	{
		case SERIAL_ONE:	
			*speed  = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_1, buf));
			*data   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_1, buf));
			*stop   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_1, buf));
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_1, buf);
			*parity =  *buf;
			break;
		case SERIAL_TWO:	
			*speed  = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_2, buf));
			*data   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_2, buf));
			*stop   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_2, buf));
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_2, buf);
			*parity =  *buf;
			break;
		case SERIAL_THREE:	
			*speed  = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_3, buf));
			*data   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_3, buf));
			*stop   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_3, buf));
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_3, buf);
			*parity =  *buf;
			break;
		case SERIAL_FOUR:	
			*speed  = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_4, buf));
			*data   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_4, buf));
			*stop   = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_4, buf));
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_4, buf);
			*parity =  *buf;
			break;
		default:
			return EFAILED;
	}
	if(*speed==0 || *data==0 || *stop==0 || *parity==0)
		return EFAILED;

	return SUCCESS;
}

int get_sqlite_net(net_t *netdp)
{
	char buf[64];

	if(netdp == NULL)
		return EFAILED;  

	memset(netdp, '\0', sizeof(net_t));

	netdp->workmod = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_WORK_MODE, buf) );
	netdp->regport = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_REGPORT, buf) );
	netdp->serPort[0] = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_1, buf) );
	netdp->serPort[1] = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_2, buf) );
	netdp->serPort[2] = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_3, buf) );
	netdp->serPort[3] = atoi( get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_4, buf) );
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_IP, netdp->ipstr);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_MASK, netdp->netmask);
	printf("mask %s\r\n", netdp->netmask);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_REG_IP, netdp->regipstr);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_GATEWAY, netdp->gateway);

	return SUCCESS;
}

int get_sqlite_passwd(char *passwd)
{
	if(passwd == NULL)
		return EFAILED;  

	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_PASSWD, passwd))
		return EFAILED;  

	return SUCCESS;
}
int get_sqlite_sysinfo(sysInfo_t *sysinfo)
{
	char devbuf[32];

	if(sysinfo == NULL)
		return EFAILED;  

	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_DEV_NAME, sysinfo->hostname))
		return EFAILED; 

	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_VERSION, sysinfo->version))
		return EFAILED; 

	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_DEVICE_ID, devbuf))
		return EFAILED; 

	sysinfo->deviceid = atoi(devbuf);

	return SUCCESS;
}
//-------------------- END  get config data ---------------------------

//-------------------- modify db config  ----------------------------
int save_db_serial(int serno, serial_t serdata)
{
	char val[4][128];

	sprintf(val[0], "%d", serdata.speed);
	sprintf(val[1], "%d", serdata.data);
	sprintf(val[2], "%d", serdata.stop);
	sprintf(val[3], "%c", serdata.parity);

	switch(serno)
	{
		case 1:
			modify_table_value(g_dbConfig, SQLITE_NAME_RATE_1, val[0]);
			modify_table_value(g_dbConfig, SQLITE_NAME_DATA_1, val[1]);
			modify_table_value(g_dbConfig, SQLITE_NAME_STOP_1, val[2]);
			modify_table_value(g_dbConfig, SQLITE_NAME_PARITY_1, val[3]);
			break;
		case 2:
			modify_table_value(g_dbConfig, SQLITE_NAME_RATE_2, val[0]);
			modify_table_value(g_dbConfig, SQLITE_NAME_DATA_2, val[1]);
			modify_table_value(g_dbConfig, SQLITE_NAME_STOP_2, val[2]);
			modify_table_value(g_dbConfig, SQLITE_NAME_PARITY_2, val[3]);
			break;
		case 3:
			modify_table_value(g_dbConfig, SQLITE_NAME_RATE_3, val[0]);
			modify_table_value(g_dbConfig, SQLITE_NAME_DATA_3, val[1]);
			modify_table_value(g_dbConfig, SQLITE_NAME_STOP_3, val[2]);
			modify_table_value(g_dbConfig, SQLITE_NAME_PARITY_3, val[3]);
			break;
		case 4:
			modify_table_value(g_dbConfig, SQLITE_NAME_RATE_4, val[0]);
			modify_table_value(g_dbConfig, SQLITE_NAME_DATA_4, val[1]);
			modify_table_value(g_dbConfig, SQLITE_NAME_STOP_4, val[2]);
			modify_table_value(g_dbConfig, SQLITE_NAME_PARITY_4, val[3]);
			break;
		default:
			return EFAILED;
	}

	return SUCCESS;
}

int save_db_passwd(char *pwd)
{
	if(pwd == NULL)
		return EFAILED;

	if(!modify_table_value(g_dbConfig, SQLITE_NAME_PASSWD, pwd)) {
		fprintf(stdout, "password modiry err\n");
		return EFAILED;
	}

	return SUCCESS;
}
int save_db_netdata(net_t netd)
{
	char val[10][128];

	sprintf(val[0], "%d", netd.serPort[0]);
	sprintf(val[1], "%d", netd.serPort[1]);
	sprintf(val[2], "%d", netd.serPort[2]);
	sprintf(val[3], "%d", netd.serPort[3]);

	sprintf(val[4], "%d", netd.workmod);
	sprintf(val[5], "%d", netd.regport);

	sprintf(val[6], "%s", netd.ipstr);
	sprintf(val[7], "%s", netd.gateway);
	sprintf(val[8], "%s", netd.netmask);
	sprintf(val[9], "%s", netd.regipstr);
	/*
	int i;
	for(i = 0; i< 10; i++)
		printf("%s\r\n", val[i]);
		*/


	//---------------------------------------

	modify_table_value(g_dbConfig, SQLITE_NAME_SERPORT_1, val[0]);
	modify_table_value(g_dbConfig, SQLITE_NAME_SERPORT_2, val[1]);
	modify_table_value(g_dbConfig, SQLITE_NAME_SERPORT_3, val[2]);
	modify_table_value(g_dbConfig, SQLITE_NAME_SERPORT_4, val[3]);
                                                                 
	modify_table_value(g_dbConfig, SQLITE_NAME_WORK_MODE, val[4]);
	modify_table_value(g_dbConfig, SQLITE_NAME_REGPORT, val[5]);
                                                                 
	modify_table_value(g_dbConfig, SQLITE_NAME_IP, val[6]);
	modify_table_value(g_dbConfig, SQLITE_NAME_GATEWAY, val[7]);
	modify_table_value(g_dbConfig, SQLITE_NAME_MASK, val[8]);
	modify_table_value(g_dbConfig, SQLITE_NAME_REG_IP, val[9]);

	return SUCCESS;
}
//-------------------- END modify db config  ----------------------------
//
//
//
//
//
//
