/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <linux/if.h>
#include <sys/ioctl.h>

int connect_plx(char *ipstr, int pot);

//读取套結字发来的消息
int read_socket(int sockfd, void *des, int len);

//通过套結字发送消息
int write_socket(int fd, void *src, int l);

//关閉套結字
void close_socket(int fd);

