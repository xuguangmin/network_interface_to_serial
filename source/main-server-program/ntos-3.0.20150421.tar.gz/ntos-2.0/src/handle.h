#ifndef __HANDLE_H_
#define __HANDLE_H_

/*---------------------------------------------------------------------------------------------
 *									include
----------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/types.h>  
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sched.h> 
#include <pthread.h>
#include "eth.h"
#include "serial.h"
#include "protocol.h"


/*
#define GROUP					"mirror:"
#define GETINI_NAME(name)		GROUP#name		
*/


//配置不存在默认采用
#define DEFAULT_SPEED			115200
#define DEFAULT_DATA			8
#define DEFAULT_PARITY			'N'
#define DEFAULT_STOP			1

#define RECEIVE					0
#define SEND					1



int server_start(void);
int server_init(void);
int server_uninit(void);




#endif//__HANDLE_H_ 

