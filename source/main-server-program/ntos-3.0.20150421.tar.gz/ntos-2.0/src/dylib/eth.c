/*-------------------------------------------------------------------------*/
/**
   @file    eth.c
   @author  g.m 

   create on: 2014年 7月 21日 
*/
/*--------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <linux/if.h>
#include <sys/ioctl.h>

extern char **environ;


/*---------------------------------------------------------------------------
                            Function codes
 ---------------------------------------------------------------------------*/
int create_socket_stream_r()
{
	int sd;
	int val, ret;

	sd = socket(AF_INET, SOCK_STREAM, 0);
	if(sd < 0)
	{
		perror("socket:\r\n");	
		exit(-1);
	}

	val = 1;
	ret = setsockopt(sd,  SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val));
	if(ret != 0)
	{
		perror("setsockopt:\r\n");	
		exit(-1);
	}
	return sd;
}
int open_socket()
{
	return create_socket_stream_r();
}

// 初始化
void init_sockaddr_in(int sa, char *ipstr, int portnum, struct sockaddr_in *addr)
{
	addr->sin_family = sa; 
	addr->sin_port = htons(portnum);   /* port in network byte order */
	inet_pton(AF_INET, ipstr, &addr->sin_addr);
}


int connect_plx(char *ipstr, int pot)
{
	int sockfd;
	int ret;
	struct sockaddr_in raddr;
	
	if((sockfd = open_socket()) < 0)
		return -1;

	init_sockaddr_in(AF_INET, ipstr, pot, &raddr);

	//连接服务端
	while(1) {
		//创建套结字
		ret = connect(sockfd, (struct sockaddr*)&raddr, sizeof(raddr));
		//如果服务端未启动,自动重连
		if(errno == ECONNREFUSED) {
			errno = 0;
			continue;
		}
		if(ret != 0) {
			perror("connect failed:");	
			//关閉所有打开的串口 
			close(sockfd);
			return -1;
		}
		break;
	}

	return sockfd;
}


//读取套結字发来的消息
int read_socket(int sockfd, void *des, int len)
{
	int ret;

	memset(des , '\0', len);

	do {
		ret = recv(sockfd, des, len, MSG_WAITALL);
		if(ret < 0) {
			perror("read: ");	
			return -1;
		} 
		if(ret == EAGAIN)
			continue;
	} while(0);

	return ret; 
}

//通过套結字发送消息
int write_socket(int fd, void *src, int len)
{
	return send(fd, src, len, 0);
}

//关閉套結字
void close_socket(int fd)
{
	close(fd);
}
