#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/types.h>  
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sched.h> 
#include <pthread.h>
#include <signal.h>
#include "eth.h"
#include "serial.h"
#include "protocol.h"
#include "handle.h"
#include "fun_exec.h"

static int register_data_init(NtosReg_t *regData, char *name, int modify);

//static pthread_cond_t  cond_buf = PTHREAD_COND_INITIALIZER;
static pthread_mutex_t mut_buf  = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t mut_sendfd  = PTHREAD_MUTEX_INITIALIZER;

#define UNUSE		-1														//文件描述符状态
#define DEV_TYPE_NTOS			1	//type of device


#define	NTOS_TABLE_SYSNFO		 "sysinfo"
#define	NTOS_DB_FILE			 "ntos-config.db"

static int seriafd[SERIALCOUNT];
static edata_e_t ptrbuf;
static int sockfd[SERIALCOUNT];
static int SendSerialSockfd[SERIALCOUNT];


static NtosReg_t *gregData;

char *S[4] = {
	"/dev/s3c2410_serial0", \
	"/dev/s3c2410_serial1", \
	"/dev/s3c2410_serial2", \
	"/dev/s3c2410_serial3", \
};
char *regProtocol[2] = {
	"REGISTER", \
	"KEEP_REGISGER", \
};


static void* recv_from_net_to_serial(void* newfd);
static int set_fd_noblock(int fd);

/*----------------------------------------------------------------------------------------------
 *									function code
----------------------------------------------------------------------------------------------*/

/*------------------------------  PUB FUNCTION  ---------------------------------*/
void mysleep(float time)
{
	long int timen = (int)(time * 1000 * 1000);
	usleep(timen);
}
//解析配置文件 "ntos-config.db"
static int load_config()
{
	if(!db_table_main_load(g_dbConfig, NTOS_TABLE_SYSNFO)) {
		fprintf(stdout, "db_table_main_load error\n");
		return EFAILED;
	}

	return SUCCESS;
}
//(get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_1, &buf)
static int get_serial_signal(int i, int *speed, int *data, int *parity, int *stop)
{
	char buf[4][128];

	if(i < 1 || i > 4 || speed == NULL || data == NULL || parity == NULL || stop == NULL) {
		fprintf(stdout, "%s %s() line:%d: set serial failed.\r\n", \
			__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}
	switch(i)
	{
		case 1:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_1,   buf[0]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_1,   buf[1]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_1, buf[2]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_1,   buf[3]);
			break;
		case 2:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_2,   buf[0]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_2,   buf[1]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_2, buf[2]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_2,   buf[3]);
			break;
		case 3:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_3,   buf[0]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_3,   buf[1]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_3, buf[2]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_3,   buf[3]);
			break;
		case 4:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_RATE_4,   buf[0]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_DATA_4,   buf[1]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_PARITY_4, buf[2]);
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_STOP_4,   buf[3]);
			break;
		default:
			printf("%d\r\n", i);
			return EBADDEVICENU;
	}
	*speed = atoi(buf[0]), *data = atoi(buf[1]), *parity = *buf[2], *stop = atoi(buf[3]);

	return SUCCESS;
}
static int 
set_serial_switch()
{
	int i = 4;
	int speed, data, parity, stop;

	while(i) {
		if(get_serial_signal(i, &speed, &data, &parity, &stop) == SUCCESS)
			internal_serial_config(seriafd[i - 1], speed, data, parity, stop);
		else
			return EFAILED;
#if DEBUG
		printf("serial:%d %d %d %d %c %d\r\n", i, seriafd[i -1], speed, data, parity, stop); 
		mysleep(0.01);
#endif
		i--;
	}

#if DEBUG
	fprintf(stdout, "set serial success!\r\n");//for debug
#endif
	return SUCCESS;
}

static int 
set_net()
{
	char lip[64];
	char lmask[64];
	//子网掩码
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_IP, lip);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_MASK, lmask);

	if(SetLocalNetMask(lmask) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: '%s' set subnetmask failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, lmask);
		goto err;
	}
									//网关....................................
	//IP
	if(ip_change(netcard_dev, lip) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d:'%s'  set ip failed.\r\n", \
				__FILE__, __FUNCTION__,  __LINE__, lip);
		goto err;
	}
	
#if DEBUG
	fprintf(stdout, "%s %s\r\n", lip, lmask);//for debug
#endif
	return SUCCESS;

err:
	return EFAILED; 
}
//通过配置文件数据配置串口参数**
//待修改8n1
static int 
set_config()		//配置信息
{
	if(set_serial_switch() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: set serial failed.\r\n", \
			__FILE__, __FUNCTION__, __LINE__);
		return EFAILED; 
	}

	if(set_net() != 0) {
		fprintf(stdout, "%s %s() line:%d: set net failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED; 
	}

	return SUCCESS;
}

//根据一个文件描述符,查找在数组中的位置
static int 
_find_cur_sockfd(int fd, const int *p, int len)
{
	int i;

	if(fd < 0 || p == NULL || len <= 0) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	for(i = 0; i < len; i++)
		if(fd == p[i])	
			return i;

	return EFAILED; 
}

//初始化存储连接文件描述符的数组
static int 
_init_array_int(int *p, int len)
{
	int i;

	if(p == NULL || len < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	for(i = 0; i < len; i++) 
		p[i] = UNUSE;

	return SUCCESS;
}

//设置线程書性分离状态
static int 
set_pthread_detach_st(pthread_attr_t *attr)
{
	if (attr == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	//设置线程書性分离状态
	pthread_attr_init(attr);
	pthread_attr_setdetachstate(attr, PTHREAD_CREATE_DETACHED);

	return SUCCESS;
}

#if DEBUG
static char * 
ask_for_page(int device)
{
	switch(device)
	{
		case 1: return "SERIAL_1";
		case 2: return "SERIAL_2";
		case 3: return "SERIAL_3";
		case 4: return "SERIAL_4";
		case 5: return "NETSTAT";
		case 6: return "PASSWORD";
		default:return NULL;	
	}

	return (char*)1;
}

static int 
print_cfg(commu_t *cfg)
{
	char pwdBuf[PWDLEN];

	if(cfg == NULL){
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	
	switch(cfg->head.device)
	{
		case SERIAL_ONE:
		case SERIAL_TWO:
		case SERIAL_THREE:
		case SERIAL_FOUR:
			fprintf(stdout, "\rntos_server %s; name='%s'; baudRate='%d' dataBit='%d' parityBit='%c' stopBit='%d'\r\n", \
					cfg->head.flag?"receive":"send", \
					ask_for_page(cfg->head.device), \
					cfg->body.serial.speed,  \
					cfg->body.serial.data,   \
					cfg->body.serial.parity, \
					cfg->body.serial.stop);
			return SUCCESS;
		case NET:
			fprintf(stdout, "\rntos_server %s; mode=%d regIp=%d %s ip='%s' mask='%s' gateWay='%s' port='%d %d %d %d'\r\n", \
					cfg->head.flag?"receive":"send", \
					cfg->body.netdata.workmod, \
					cfg->body.netdata.regport, \
					cfg->body.netdata.regipstr, \
					cfg->body.netdata.ipstr, \
					cfg->body.netdata.netmask, \
					cfg->body.netdata.gateway, \
					cfg->body.netdata.serPort[0], \
					cfg->body.netdata.serPort[1], \
					cfg->body.netdata.serPort[2], \
					cfg->body.netdata.serPort[3]);
			return SUCCESS;
		case PWD:
			memcpy(pwdBuf, cfg->body.pwd, cfg->head.length);
			fprintf(stdout, "\rntos_server %s; password='%s'\r\n", \
					cfg->head.flag?"receive":"send", \
					pwdBuf);
		default:
			return EPARAMETER;
	}

	return SUCCESS;
}
#endif

static int 
save_cfg_db (commu_t *recvDatap)
{
	int ret;
	char pwdBuf[PWDLEN];
	int deviceNum = recvDatap->head.device;
	body_t body = recvDatap->body;

	if(recvDatap == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	switch(deviceNum)
	{
		case SERIAL_ONE:
		case SERIAL_TWO:
		case SERIAL_THREE:
		case SERIAL_FOUR:
			if((ret = save_db_serial(deviceNum, body.serial)) != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			break;
		case NET:
			if((ret = save_db_netdata(body.netdata)) != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			break;
		case PWD:	
			memcpy(pwdBuf, body.pwd, recvDatap->head.length);
			pwdBuf[recvDatap->head.length]= '\0';
			if((ret = save_db_passwd(pwdBuf)) != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			break;
		default:
			return EPARAMETER;
	}

	return SUCCESS;
}

//设置单个文件描述符非阻塞
static int 
set_fd_noblock(int fd)
{
	int ret;
	int fd_save;

	if(fd < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \

				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	do {
		fd_save = fcntl(fd, F_GETFL);
		if((ret = fcntl(fd, F_SETFL,fd_save|O_NONBLOCK)) < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			return EFAILED;
		}
	} while(ret == EAGAIN);

	return SUCCESS;
}

//设置所有串口文件描述符非阻塞
static int 
set_fd_noblock_all(int *fd, int num)
{
	int i;
	if(fd == NULL || num <0) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	for(i = 0; i < num; i++)
		if(set_fd_noblock(seriafd[i]) != 0)
			return EFAILED;
		else
			continue;
	return SUCCESS;
}
/*------------------------------  END PUB FUNCTION  ---------------------------------*/

/*------------------------------	FOR CGI   ---------------------------------*/
//apply_new_cfg();
static int 
apply_new_cfg(commu_t *recvDatap)
{
	int ret;

	if(recvDatap == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	switch(recvDatap->head.device)
	{
		case SERIAL_ONE:
		case SERIAL_TWO:
		case SERIAL_THREE:
		case SERIAL_FOUR:
			ret = set_serial_switch(recvDatap->head.device, (serial_t*)&recvDatap->body.serial);
			break;
		case NET:
			ret = set_net((net_t *)&recvDatap->body.netdata);
			register_data_init(gregData, NULL, 1);
			/*
			close(sockfd);
			sockfd = create_socket_stream_r();
			init_sockaddr_in(AF_INET, recvDatap->body.netdata.ipstr, recvDatap->body.netdata.port, &laddr);
			bind_v4(sockfd, &laddr, sizeof(laddr));
			my_listen(sockfd, 20);
			*/
			break;
		case PWD:
			ret = SUCCESS;
			break;
		default:
			return EPARAMETER;
	}

	if(ret == SUCCESS)
		return SUCCESS;
	else
		return EAPPLYINI;
}

static int 
send_data_switch(int sock, commu_t *senDatap)
{
	int len; 

	if(sock < 0 || senDatap->head.device < 0 || senDatap->head.device > DEVICE_TOTAL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	switch(senDatap->head.device)	
	{
		case SERIAL_ONE:	
		case SERIAL_TWO:	
		case SERIAL_THREE:	
		case SERIAL_FOUR:	
			if(get_sqlite_serial(senDatap->head.device, &(senDatap->body.serial))){
				fprintf(stdout, "%s %s() line:%d: get_sqlite_serial failed.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			len = sizeof(serial_t);
			break;
		case NET:
			if(get_sqlite_net(&(senDatap->body.netdata))) {
				fprintf(stdout, "%s %s() line:%d: get_sqlite_net failed.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			len = sizeof(net_t);
			break;
		case PWD:	
		case LOGIN:	
			if(get_sqlite_passwd(senDatap->body.pwd)) {
				fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			len = strlen(senDatap->body.pwd) + 1;
			break;
		case SYSINFO:	
			if(get_sqlite_sysinfo(&(senDatap->body.sysInfo))){
				fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return EFAILED;
			}
			len = sizeof(sysInfo_t);
			break;
		default:
			return EFAILED;
	}
	senDatap->head.length = len;
	if(send(sock,  senDatap, sizeof(commu_t), 0) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return ERETVAL;
	}

	return SUCCESS;
}
//CGI INTERFACE
static void* 
setup_device(void *p)
{
	struct sockaddr_un address;
	int sock, conn;
	size_t addrLength;
	int ret;

	if ((sock = socket(PF_UNIX, SOCK_STREAM, 0)) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return NULL;
	}

	/* Remove any preexisting socket (or other file) */
	unlink(DOMAIN_SOCKET);
	address.sun_family = AF_UNIX;       /* Unix domain socket */
	strcpy(address.sun_path, DOMAIN_SOCKET);

	/* The total length of the address includes the sun_family
	 *        element */
	addrLength = sizeof(address.sun_family) + strlen(address.sun_path);

	if (bind(sock, (struct sockaddr *) &address, addrLength)) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return NULL;
	}
	if (listen(sock, 10)) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return NULL;
	}

	commu_t *recvDatap = (commu_t *)malloc(sizeof(commu_t));
	while (1)
	{
		if((conn = accept(sock, (struct sockaddr *) &address, &addrLength)) > 0) {
			if(load_config() != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: load config failed.\r\n", \
						__FILE__, __FUNCTION__, __LINE__);
				return NULL;
			}
			
			//wait for new data
			if((ret = recv(conn, recvDatap, sizeof(commu_t), 0)) < 0) {
				fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
						__FILE__, __FUNCTION__, __LINE__, strerror(errno));
				close(conn);
			} else if (ret <= 0) {
				fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
						__FILE__, __FUNCTION__, __LINE__, strerror(errno));
				close(conn);
				continue;
			}

			//newcfg.flag : R = 0客戶端获取;  T = 1 客戶端保存
			if (recvDatap->head.flag == RECEIVE) {
				if(send_data_switch(conn, recvDatap) < 0) 
					fprintf(stdout, "server send_data_switch failed\r\n");
				else {
#if DEBUG
					print_cfg(recvDatap);
#endif
				}

			} else if (recvDatap->head.flag == SEND) {
				save_cfg_db (recvDatap);
				apply_new_cfg(recvDatap);
#if DEBUG
				print_cfg(recvDatap);
#endif
			}
			close(conn);
		}
		if (conn < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			continue;
		}
	}
	return (void*)1;
}
/*------------------------------  END FOR CGI   ---------------------------------*/

/*------------------------------  NETWORK   --------------------------------*/
static int 
insert_new_link(int index, int newsd)
{
	ptrbuf.sockfd[index] = newsd;
#if DEBUG
	printf("ptrbuf.sockfd[%d] = %d\r\n", index, newsd);
#endif

	return SUCCESS;
}
static void 
del_new_link(int newfd)
{
	int i; 

	close(newfd);
	i = _find_cur_sockfd(newfd, ptrbuf.sockfd, MAX_LINK);			
	ptrbuf.sockfd[i] = UNUSE;
}
static int 
accept_for_new_task()
{
#if DEBUG
	char ipstr[IP_LEN];
#endif
	pthread_t tid;
    struct sockaddr_in raddr;
	pthread_attr_t attr;
	int i, newsd;

	//设置线程書性分离状态
	if(set_pthread_detach_st(&attr) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	//循环接收多个网络连接任务
	socklen_t raddr_len = sizeof(raddr);
	i = 0;
	while(1) {
#if DEBUG
		printf("wait for connect ...\r\n");
#endif
		while(1) {
			if(ptrbuf.sockfd[i] == UNUSE) {
				//printf("ptrbut.sockfd[%d] = %d port = %d\r\n", i, ptrbuf.sockfd[i], conf.netdata.serPort[i]);
				newsd = accept(sockfd[i],(void *)&raddr,&raddr_len);
				if(newsd == EAGAIN || newsd == EWOULDBLOCK) {
					goto accerr;
				} else if(newsd < 0) {
#if !DEBUG
					fprintf(stdout, "%s %s() line:%d: sock %d %s.\r\n", \
							__FILE__, __FUNCTION__, __LINE__, sockfd[i], strerror(errno));
#endif
					goto accerr;
				} else {
					break;
				}
			}
			if(i == 3)
				i = 0;
			else
				i++;
			continue;
accerr:
			if(i == 3)
				i = 0;
			else
				i++;
		}
#if DEBUG
		printf("----------------------   ok  ------------------------\r\n");
#endif

		insert_new_link(i, newsd);
#if DEBUG
		//打印链接信息
		inet_ntop(AF_INET, &raddr.sin_addr, ipstr, sizeof(ipstr));
		fprintf(stdout, "serial:%d ip:%s port:%d\r\n",  \
				i, ipstr, ntohs(raddr.sin_port));
#endif
		if(pthread_create(&tid, &attr, recv_from_net_to_serial, (void*)&newsd) != 0) { 
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			del_new_link(newsd);
#if DEBUG
			fprintf(stdout, "end work error!!!\r\n");
#endif
			continue;
		}
	}

	return SUCCESS;
}
static int
get_regport(int i)
{
	int mode;
	char buf[32];

	switch(i)
	{
		case 1:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_1, buf);
			break;
		case 2:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_2, buf);
			break;
		case 3:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_3, buf);
			break;
		case 4:
			get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_4, buf);
			break;
		default:
			return -1;
	}
	mode = atoi(buf);
	return mode;
}
//接收网络连接任务请求
static int 
link_new_server()
{
	int i;
	int mode;
	char locipstr[64];
	struct sockaddr_in	laddr;

	printf("create socket start!!!\r\n");
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_IP, locipstr);
	for(i = 0; i < SERIALCOUNT; i++) {
		if((sockfd[i] = create_socket()) < 0) {
			fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
			return EFAILED;
		} 
		set_fd_noblock(sockfd[i]);

		if((mode = get_regport(i+1)) < 0) {
			fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
			return EFAILED;
		}
		printf("%s  %d\r\n", locipstr, mode);
		init_sockaddr_in(AF_INET, locipstr, mode, &laddr);
		if(bind_v4(sockfd[i], &laddr, sizeof(laddr)) != SUCCESS) {
			fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
			return EFAILED;
		}
		if(my_listen(sockfd[i], 20) != SUCCESS) {
			fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
			return EFAILED;
		}
	}

	printf("create socket success!!!\r\n");

	if(accept_for_new_task() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	return SUCCESS;
}

static void* 
recv_from_net_to_serial(void* newfd)
{
	int len;
	int fd;
	char rbuf[BUFSIZE];												
	//网口通信协义结构

	if(newfd == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return NULL;
	}

	fd = *(int *) newfd;
	set_fd_noblock(fd);

	if(newfd < 0)
		del_new_link(fd);

	while(1) {
		memset(rbuf, '\0', sizeof(rbuf));
		len = read_socket(fd, rbuf, BUFSIZE);		//接收数据
		if(len == 0) {
			break;
		} else if(len < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			break;
		}
		//发送数据
		chose_serial_send(seriafd, _find_cur_sockfd(fd, ptrbuf.sockfd, MAX_LINK), rbuf, strlen(rbuf));
		SendSerialSockfd[_find_cur_sockfd(fd, ptrbuf.sockfd, MAX_LINK)] = fd;
#if DEBUG
		fprintf(stdout, "recv_from_net_to_serial %d: %s\r\n", _find_cur_sockfd(fd, ptrbuf.sockfd, MAX_LINK), rbuf);
#endif
	}

	del_new_link(fd);

#if DEBUG
	fprintf(stdout, "END !!!\r\n");
#endif
	return (void*)1;
}
/*------------------------------  END NETWORK   --------------------------------*/

/*------------------------------  SERIAL  --------------------------------------*/

//读取所有串口,如果有数据到来,回填数据,反回串口号
static int 
read_serial_all(const int *seriafd, void *p, int lenpara)
{
	int i = 0, len = 0;

	memset(p, '\0', lenpara);
	
	if(seriafd == NULL || lenpara <= 0) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	for(i = 0; 1; i++) {
		if(i == 3)  
			i = 0;
		len = serial_read(seriafd[i], p, lenpara);
		if(len == 0) 
			continue;
		else if(len < 0) {
#if DEBUG
			//fprintf(stdout, "%s %s() line:%d: i %d parameter is NULL.\r\n", __FILE__, __FUNCTION__, __LINE__, i);
#endif
			continue;
		}


#if DEBUG
		fprintf(stdout, "%s\r\n", (char*)p);
#endif
		return i;
	}

	return SUCCESS;
}

static void* 
server_loop_serial(void *p)
{
	int serialnum;
	char sbuf[BUFSIZE];

	//设置所有串口文件描述符非阻塞
	set_fd_noblock_all(seriafd, SERIALCOUNT);				

	while(1) {
		memset(sbuf, '\0', BUFSIZE);
		//接收串口数据
		if((serialnum = read_serial_all(seriafd, sbuf, BUFSIZE)) < 0 || serialnum > SERIALCOUNT){
			fprintf(stdout, "serialNum invalid\r\n");
			continue;
		}

#if DEBUG
		printf("serial send: %s\r\n", sbuf);
#endif
		//发送数据到网络链接
		if(send(SendSerialSockfd[serialnum], sbuf, strlen(sbuf), 0) < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			continue;
		}
	}

	return (void *)1;
}
/*------------------------------  END SERIAL  --------------------------------------*/

/*------------------------------  REGISTER  --------------------------------------*/
static int register_data_init(NtosReg_t *regData, char *name, int modify)
{
	char lip[64];
	char port[4][8];
	if(regData == NULL || name == NULL) {
		return -1;	
	}
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_IP, lip);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_1, port[0]);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_2, port[1]);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_3, port[2]);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_SERPORT_4, port[3]);

	strcpy(regData->name, name);
	regData->modify = modify;

	regData->devType = DEV_TYPE_NTOS;
	regData->originalVal = regData->presentVal;
	strcpy(regData->presentVal.ipaddr, lip);
	regData->presentVal.port[0] = atoi(port[0]);
	regData->presentVal.port[1] = atoi(port[1]);
	regData->presentVal.port[2] = atoi(port[2]);
	regData->presentVal.port[3] = atoi(port[3]);
	regData->retStatus = -1;

	return SUCCESS;
}

int conn_nonb(int sockfd, const struct sockaddr_in *saptr, socklen_t salen, int nsec)   
{
	int flags, n = 0, error, code;   
	socklen_t len;   
	fd_set wset;   
	struct timeval tval;   

	flags = fcntl(sockfd, F_GETFL, 0);   
	fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

	error = 0;   
	if ((n == connect(sockfd, (void *)saptr, salen)) == 0) {   
		goto done;
	} else if (n < 0 && errno != EINPROGRESS){   
		return (-1);   
	}

	/* Do whatever we want while the connect is taking place */  

	FD_ZERO(&wset);   
	FD_SET(sockfd, &wset);   
	tval.tv_sec = nsec;
	tval.tv_usec = 0;   

	if ((n = select(sockfd, NULL, &wset, NULL, nsec ? &tval : NULL)) == 0) {   
		close(sockfd);  /* timeout */  
		errno = ETIMEDOUT;   
		return (-1);   
	}   

	if (FD_ISSET(sockfd, &wset)) {
		len = sizeof(error);
		code = getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len);   
		/* 如果发生错误，Solaris实现的getsockopt返回-1，  
		 * 把pending error设置给errno. Berkeley实现的  
		 * getsockopt返回0, pending error返回给error.   
		 * 我们需要处理这两种情况 */
		if (code < 0 || error) {
			close(sockfd);
			if (error)
				errno = error;
			return (-1);   
		}
	} else {   
		fprintf(stderr, "select error: sockfd not set");   
		return -1; //return 0
	}   

done:   
	fcntl(sockfd, F_SETFL, flags);  /* restore file status flags */  
	return (0);   
}  
static void alrm_handler(int s)
{
	int val;
	int sock;
	char lipstr[64], port[8];
	struct sockaddr_in raddr;
#if DEBUG
	char *buf;
#endif

	sock = socket(AF_INET,SOCK_STREAM,0);
    if(sock < 0) {
        perror("socket()");
		return;
    }

	val = 1;
	if((setsockopt(sock,  SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val))) != 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return ;
	}

	//get ip
	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_REG_IP, lipstr)) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return ;
	}
	//get port
	if(!get_datastr(db_table_cfg_value_init, SQLITE_NAME_REGPORT, port)) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return ;
	}

	raddr.sin_family = AF_INET;
	raddr.sin_port = htons(atoi(port));
	inet_pton(AF_INET, lipstr, &raddr.sin_addr);

	if(conn_nonb(sock, &raddr, sizeof(raddr), 3) == SUCCESS) {
		if(gregData->modify == 1) {
			if(register_data_init(gregData, regProtocol[0], 0) != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: modyfy:%d register_data_init() failed.\r\n", \
						__FILE__, __FUNCTION__, __LINE__, gregData->modify);
				return;
			}
#if DEBUG
			fprintf(stdout, "%s() line:%d: modify is 1\r\n", __FUNCTION__, __LINE__);
#endif
		} else { 
			if(register_data_init(gregData, regProtocol[1], 0) != SUCCESS) {
				fprintf(stdout, "%s %s() line:%d: modyfy:%d register_data_init() failed.\r\n", \
						__FILE__, __FUNCTION__, __LINE__, gregData->modify);
				return ;
			} 
#if DEBUG
				fprintf(stdout, "%s() line:%d: modify is 0\r\n", __FUNCTION__, __LINE__);
#endif
		}
	} else {
		fprintf(stdout, "%s %s() line:%d: conn_nonb() failed.\r\n", __FILE__, __FUNCTION__, __LINE__);
		return ;
	}

#if DEBUG
	fprintf(stdout, "%s() line:%d test 'Hello World'\r\n", __FUNCTION__, __LINE__);
	buf = "Hello World!!!";
	write(sock, buf, strlen(buf)+1);
#else
	write(sock, &gregData, sizeof(gregData));
#endif

	close(sock);
}

static void *
server_loop_register(void *s)
{
	gregData = malloc(sizeof(NtosReg_t));
	if(gregData == NULL) {
		fprintf(stdout, "%s %s() line:%d: malloc failed.\r\n", __FILE__, __FUNCTION__, __LINE__);
		return NULL;
	}

	register_data_init(gregData, regProtocol[0], 1);

	while(1) {
		alrm_handler(0);
		sleep(REGISTER_SECOND_TIME);
	}

	free(gregData);

	return SUCCESS;
}

/*------------------------------  END REGISTER  --------------------------------------*/

/*------------------------------  config ini file  --------------------------------------*/
static void* fopen_config_ini(char *fname)
{
	FILE *fp;

	if(fname == NULL)
		return NULL;
	if((fp = fopen(fname, "w+")) != NULL) {
		return fp;
	}

	return NULL;
}
static int modify_config_ini(FILE *fp, char *key, char *data)
{
	char lbuf[BUFSIZE];

	if(fp == NULL || key == NULL || data == NULL)
		return EFAILED;

	memset(lbuf, '\0', BUFSIZE);

	if(!strcasecmp(key, SQLITE_NAME_IP)) {
		sprintf(lbuf, "%s = %s\n", SQLITE_NAME_IP, data);
	} else if(!strcasecmp(key, SQLITE_NAME_GATEWAY)) {
		sprintf(lbuf, "%s = %s\n", SQLITE_NAME_GATEWAY, data);
	} else if(!strcasecmp(key, SQLITE_NAME_MASK)) {
		sprintf(lbuf, "%s = %s\n", SQLITE_NAME_MASK, data);
	} else {
		return EFAILED;
	}

	fwrite(lbuf, strlen(lbuf), 1, fp);

	return SUCCESS;
}

/*------------------------------  end config ini file  --------------------------------------*/

/*------------------------------  SERVER INTERFACE  --------------------------------------*/
extern int 
server_start(void)
{
	int mode;
	char buf[8];
	pthread_t tid;
	pthread_attr_t attr;


	//设置线程書性分离状态
	if(set_pthread_detach_st(&attr) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	printf("\r\nstart serial receive >>>>>>>>>>>>>>>>>>>>>>>>>>>>\r\n");
	//启接收串口数据任务
	if(pthread_create(&tid, &attr, server_loop_serial, NULL) < 0) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;  
	}

	printf("start CGI >>>>>>>>>>>>>>>>>>>>>>>>>>>>\r\n");
	//设置设备 CGI
	if(pthread_create(&tid, &attr, setup_device, NULL) < 0) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;  
	}

	printf("start net receive connect >>>>>>>>>>>>>>>>>>>>>>>>>>>>\r\n");

	if(get_datastr(db_table_cfg_value_init, SQLITE_NAME_WORK_MODE, buf))
		mode = atoi(buf);
	else {
		fprintf(stdout, "%s %s() line:%d  link_new_server() get workmod error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}
	mysleep(3);

	//接收网络连接任务请求
	if(mode == 0) {
		fprintf(stdout, "%s %s() line:%d  now into link_new_server() workmod:server +++\r\n", __FILE__, __FUNCTION__, __LINE__);
		link_new_server();
	} else if (mode == 1) {
		fprintf(stdout, "%s %s() line:%d  now into link_new_server() workmod:client +++\r\n", __FILE__, __FUNCTION__, __LINE__);
		return SUCCESS;
	} else if (mode == 2) {
		fprintf(stdout, "%s %s() line:%d  now into register pthread() +++\r\n", __FILE__, __FUNCTION__, __LINE__);
		//向主机注册信息
		if(pthread_create(&tid, &attr, server_loop_register, NULL) < 0) {
			fprintf(stdout, "%s %s() line:%d +++\r\n", __FILE__, __FUNCTION__, __LINE__);
			return EFAILED; 
		}
		fprintf(stdout, "%s %s() line:%d  now into link_new_server() +++\r\n", __FILE__, __FUNCTION__, __LINE__);
		link_new_server();
	}
	else
		fprintf(stdout, "%s %s() line:%d program wordmod '%d' isn't found and going exit\r\n", __FILE__, __FUNCTION__, __LINE__, mode);


	return SUCCESS;
}

//initialization environment
extern int 
server_init(void)
{
	int i, flag, ret;
#if DEBUG
	char buf[64];
#endif

	memset(&ptrbuf, '\0', sizeof(ptrbuf));
	_init_array_int(ptrbuf.sockfd, MAX_LINK);
	ptrbuf.lcount = 0;

	for(i = 0; i < SERIALCOUNT; i++) {
		ptrbuf.sockfd[i] = -1;
	}


	//打开所有串口 serial3
	for(i = 0; i < SERIALCOUNT; i++) {
		if((seriafd[i] = serial_open(S[i])) < 0) {
			flag = seriafd[i];
		}
	}
	mysleep(0.01);
#if DEBUG
	if(flag < 0) {
		fprintf(stdout, "serial open failed!!!\r\n");//for debug
		return EFAILED;
	} else {
		fprintf(stdout, "serial open success!!!\r\n");//for debug
	}
#endif

	//解析配置文件"config.ini"
	ret = sqlite3_open(NTOS_DB_FILE, &g_dbConfig);
	if(ret) {
		mysleep(0.01);
		fprintf(stderr, "Can't open database:%s\n", sqlite3_errmsg(g_dbConfig));	
		sqlite3_close(g_dbConfig);
		return EFAILED;
	}
	if(load_config() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: load config failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	int m;
	FILE *fp;

	if((fp = fopen_config_ini(USR_CONF_FILE)) == NULL) {
		fprintf(stdout, "%s %s() line:%d: open %s failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, USR_CONF_FILE);
	} else {
		for(m = 0; strcmp(db_table_cfg_value_init[m].key_name, "END") != 0; m++) {
			if(modify_config_ini(fp, db_table_cfg_value_init[m].key_name, db_table_cfg_value_init[m].value) == SUCCESS) {
				fprintf(stdout, "modify %s  %s=%s success.\r\n", \
					USR_CONF_FILE, db_table_cfg_value_init[m].key_name, db_table_cfg_value_init[m].value);
			}
			fprintf(stdout, "%s = %s\r\n", db_table_cfg_value_init[m].key_name, db_table_cfg_value_init[m].value);
			mysleep(0.01);
		}
		fclose(fp);
	}
	
	//解析配置文件"ntos-config.db"
#if DEBUG
	fprintf(stdout, "get config success!\r\n");
#endif

	//通过配置文件数据配置串口参数**
	if(set_config() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: set config failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

#if DEBUG
	mysleep(0.01);
	get_datastr(db_table_cfg_value_init, SQLITE_NAME_PASSWD, buf);
	fprintf(stdout, "password: %s\r\n", buf); // output password
#endif

#if !DEBUG
	//转移控制台至tty1
	if(reset_console_tty(CONSOLE_NEW) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: shift console to %s failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, CONSOLE_NEW);
		return EFAILED;
	}
	fprintf(stdout, "shift console to %s''\r\n", CONSOLE_NEW);
#endif


	printf("initialization OK!!!\r\n");
	return SUCCESS;
}

//recovery environment
extern int 
server_uninit(void)
{
	int i;
#if !DEBUG
	//recovery console
	if(reset_console_tty(CONSOLE_ORIGINAL) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: restore console to %s failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, CONSOLE_ORIGINAL);
		return EFAILED;
	}
#endif

	if(serial_close_all(seriafd) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: restore console to %s failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, CONSOLE_ORIGINAL);
		return EFAILED;
	}

	pthread_mutex_destroy(&mut_buf);
	pthread_mutex_destroy(&mut_sendfd);
	
	for(i = 0; i < SERIALCOUNT; i++)
		close(sockfd[i]);

	sqlite3_close(g_dbConfig);
	return SUCCESS;
}
/*------------------------------  END SERVER INTERFACE  --------------------------------------*/

//for debug
FILE* 
afreshOrient(const char *fname, const char *mode, FILE *stream)
{
	FILE *nfp;

	nfp = freopen(fname, mode, stream);
	if(nfp == NULL) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, \
				__FUNCTION__, __LINE__, strerror(errno));
		return NULL;
	}

	return  nfp;
}
