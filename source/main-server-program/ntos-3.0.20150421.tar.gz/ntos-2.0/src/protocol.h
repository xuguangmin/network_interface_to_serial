/*---------------------------------------------------------------------------
 *
 * 文件: protocol.h
 * 日期: 2014年 7月 21日 
 *
 ---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/

#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>					/* superset of previous */

#define		DEBUG				0

#define		SERVER_SIDE			0			//device is server
#define		SERIALCOUNT			4			//串口数
#define		MAX_LINK			SERIALCOUNT	//最大链接数
#define		BUFSIZE				1024		//数据缓冲区大小
#define		netcard_dev			"eth0"		//以太网设备
#define		USR_CONF_FILE		"/etc/ntos/config.ini"
#define		DOMAIN_SOCKET		"/etc/ntos/sample-socket"
#define STARTCH		'#'				//数据开始标志
#define ENDCH		'!'				//数据結束标志

#define REGISTER_SECOND_TIME	3	//注册延时
//work mode
#define MODE_SERVER				1	//is server 
#define MODE_CLIENT				2	//is client 
#define MODE_REGIST				3	//is register



#define DEVICE_TOTAL		8
//device number
#define SERIAL_ONE				1	
#define SERIAL_TWO				2	
#define SERIAL_THREE			3
#define SERIAL_FOUR				4
#define NET						5
#define PWD						6
#define LOGIN					7
#define SYSINFO  				8



#define		SUCCESS					0		//success
#define		EFAILED					-1		//faile
#define		ENOTOPENFILE			-2		//open file error, serial_device or net device
#define		EBADDEVICENU			-3		//device num is not support
#define		EPARAMETER			    -4		//function parameter error
#define		ERETVAL					-5		//lib function return val
#define		ESAVEINI				-6		//save failed
#define		EAPPLYINI				-7		//apply config file

#define CONSOLE_ORIGINAL				"/dev/tty0"
#define CONSOLE_NEW						"/dev/tty1"
/*---------------------------------------------------------------------------
                                New types
 ---------------------------------------------------------------------------*/

//配置文件结构体
typedef struct __serial_t
{
	int  speed;
	int  data;
	int  stop;
	int  parity;
}serial_t;
typedef struct __net_t
{
#define		IP_LEN				64			//IP长度
	char ipstr[IP_LEN];
	int  workmod;
	int  serPort[SERIALCOUNT];
	char gateway[IP_LEN];
	char netmask[IP_LEN];
	char regipstr[IP_LEN];
	int  regport;
}net_t;
typedef struct _sysInfo_t
{
#define	SYSINFO_STRLEN	32
	char hostname[SYSINFO_STRLEN];
	char version[SYSINFO_STRLEN];
	int  deviceid;
}sysInfo_t;

typedef struct __conf_t
{
#define PWDLEN	16
	serial_t serial[SERIALCOUNT];
	net_t	 netdata;
	sysInfo_t sysInfo;
	char     key[PWDLEN];
}conf_t;

typedef struct {
	int	flag;		// 0获取,1保存
	int	device;	//device number	
	int length;	//length of body_t
}head_t;
typedef union 
{
	sysInfo_t sysInfo;
	serial_t serial;
	net_t    netdata;
	char     pwd[PWDLEN];
}body_t;
typedef struct 
{
	head_t head;
	body_t body;	
}commu_t;

//注册信息结构体
#define MAX_NTOS_STR_LEN  128
typedef  struct val{
	char			ipaddr[MAX_NTOS_STR_LEN];    //参数值
	int 			port[4];
}stValue_t;
typedef struct _variant
{
	int			devType;					//设备类型：网口转串口设备注册协议
	char		name[MAX_NTOS_STR_LEN];		//参数名称: 注册 || 重新注册 || 注册保持 || 取消注册 
	int			modify;						//是否修改：true || flase
	stValue_t	originalVal;				//修改前的值
	stValue_t	presentVal;					//修改后的值
	int			retStatus;					//参数设置状态：成功 || 失败 || 未识别
	char		msg[MAX_NTOS_STR_LEN];					//错误信息
	char		szReverse[MAX_NTOS_STR_LEN];			//扩展预留
}NtosReg_t;	//参数定义


/*--------------------------------------------------------------------------*/
 /**
 说明: 这个结构体定义了从网络端接收到的数据类型协义格式,数据被提取后通过串口端
 发送出去;serial保存了要发的串口,data保存了发送的数据.	
 网络端输入数据格式： 命令 串口号
 串口端输出数据格式:  命令  
 */
/*--------------------------------------------------------------------------*/
typedef struct _edata_t_e {
	int lcount;							//当前链接数count--
	int sockfd[MAX_LINK];				//连接
	char edata[0];						//需发送的数据
}edata_e_t;

#define EDATA_LEN		sizeof(edata_t)
#define EDATA_E_LEN		sizeof(edata_e_t)

/*--------------------------------------------------------------------------*/
 /**
 说明: 这个结构体定义了从串口端接收到的数据类型协义格式,数据被重新封装成edata_t
 格式通过网络链接发送到每个链接上;用戶应根据需求自己决定是否接收指定串口发来的
 数据,data保存了数据的內容.
 串口输入数据格式: #字符串!
 网络输出数据格式：字符串 串口号
 */
/*--------------------------------------------------------------------------*/
typedef struct _sdata_t {
	char data[BUFSIZE];					//数据
}sdata_t;

#define SDATA_LEN		sizeof(sdata_t)

#endif	/* __PROTOCOL_H__ */

