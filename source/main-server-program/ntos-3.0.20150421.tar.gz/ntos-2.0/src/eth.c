/*-------------------------------------------------------------------------*/
/**
   @file    eth.c
   @author  g.m 

   create on: 2014年 7月 21日 
*/
/*--------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <linux/if.h>
#include <sys/ioctl.h>
#include "eth.h"
#include "protocol.h"

extern char **environ;


/*---------------------------------------------------------------------------
                            Function codes
 ---------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*/
/**
  @brief    创建套接字；基于IPv4的流式套接字
  @param    
  @return   成功返回套接字文件描述符；失败返回-1
 */
int create_socket()
{
	int sd;
	int val, ret;

	if((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	val = 1;
	if((ret = setsockopt(sd,  SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val))) != 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	return sd;
}

void init_sockaddr_in(int sa, char *ipstr, int portnum, struct sockaddr_in *addr)
{
	addr->sin_family = sa; 
	addr->sin_port = htons(portnum);   /* port in network byte order */
	inet_pton(AF_INET, ipstr, &addr->sin_addr);
}

//绑定套结字
int bind_v4(int sockfd, struct sockaddr_in *addr, socklen_t addrlen)
{
	int ret;

	if(sockfd < 0 || addr == NULL || addrlen < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	if((ret = bind(sockfd, (struct sockaddr*)addr, addrlen)) != 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	return SUCCESS;
}

//监听套结字
int my_listen(int sockfd, int backlog) 
{
	if(sockfd < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	if(listen(sockfd, backlog) != 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	return SUCCESS;
}

//等带连接请求 
int my_accept(int sockfd, struct sockaddr_in *addr,  unsigned int addrlen)
{
	int newsd;

	do {
		newsd = accept(sockfd, (struct sockaddr*)addr, (socklen_t*)&addrlen);
	} while( newsd == EAGAIN || newsd == EWOULDBLOCK);
	if(newsd < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	return newsd;
}

//读取套結字发来的消息
int read_socket(int sockfd, void *des, int size)
{
	int ret = 0;
	int len = 0;

	if(sockfd < 0 || des == NULL || size < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	memset(des , '\0', 1024);

	while(1)
	{
		ret = recv(sockfd, des, size, MSG_DONTWAIT);
		if(ret > 0)
			return ret;
		else if(ret == 0) {
#if DEBUG
			//fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
#endif
			return ret;
		} else if(errno == EAGAIN || errno ==EWOULDBLOCK) {
#if DEBUG
			//fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
#endif
			continue;
		} else if(ret < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
			return ret;
		}
	}

	return len; 
}

//通过套結字发送消息
int write_socket(int fd, void *src, int l)
{
	int ret = 0, len = 0, pos = 0;

	if(fd < 0 || l <= 0 || src == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	while(1)
	{
		ret = send(fd, src, l, 0);
		if(ret < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
			return ret;
		} else if(ret == EAGAIN) {
#if DEBUG
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
#endif
			continue;
		} else if (ret < l)	{
			//可能被中断打断,继续写 
			pos += ret;	
			len += pos;
			continue;
		}

		//无异常,向下执行 
		if (ret == l)
			return SUCCESS;
	}

	return SUCCESS;
}
//关閉套結字
void close_sockfd(int fd)
{
	close(fd);
}

//修改IP
int ip_change(char *dev, char *ipaddr)
{
	int sock_set_ip;  
	struct sockaddr_in sin_set_ip;  
	struct ifreq ifr_set_ip;  

	if(dev == NULL || ipaddr == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	bzero( &ifr_set_ip,sizeof(ifr_set_ip));  

	if((sock_set_ip = socket( AF_INET, SOCK_STREAM, 0 )) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;  
	}  

	memset( &sin_set_ip, 0, sizeof(sin_set_ip));  
	strncpy(ifr_set_ip.ifr_name, dev, sizeof(ifr_set_ip.ifr_name)-1);     

	sin_set_ip.sin_family = AF_INET;  
	sin_set_ip.sin_addr.s_addr = inet_addr(ipaddr);  
	memcpy( &ifr_set_ip.ifr_addr, &sin_set_ip, sizeof(sin_set_ip));  

	if(ioctl( sock_set_ip, SIOCSIFADDR, &ifr_set_ip) < 0) {
		fprintf(stdout, "%s %s() line:%d: '%s' %s.\r\n", __FILE__, __FUNCTION__, __LINE__, ipaddr, strerror(errno));
		return EFAILED;  
	}

	//设置激活标志  
	ifr_set_ip.ifr_flags |= IFF_UP |IFF_RUNNING;  

	//get the status of the device
	if(ioctl(sock_set_ip, SIOCSIFFLAGS, &ifr_set_ip) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;  
	} 

	close(sock_set_ip);  
	return SUCCESS; 
}

//修改子NETMASK的函数
int SetLocalNetMask(const char *szNetMask)  
{
	int sock_netmask;  

	struct ifreq ifr_mask;  
	struct sockaddr_in *sin_net_mask;  

	if((sock_netmask = socket(AF_INET, SOCK_STREAM, 0 )) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;  
	} 

	memset(&ifr_mask, 0, sizeof(ifr_mask));     
	strncpy(ifr_mask.ifr_name, "eth0", sizeof(ifr_mask.ifr_name)-1);     
	sin_net_mask = (struct sockaddr_in *)&ifr_mask.ifr_addr;  
	sin_net_mask -> sin_family = AF_INET;  
	inet_pton(AF_INET, szNetMask, &sin_net_mask->sin_addr);  

	if(ioctl(sock_netmask, SIOCSIFNETMASK, &ifr_mask) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s.\r\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;  
	}  

	return SUCCESS;
}  


