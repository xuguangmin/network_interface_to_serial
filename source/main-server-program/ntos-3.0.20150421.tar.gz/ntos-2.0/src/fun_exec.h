/******************************************************************************

                  ��Ȩ���� (C), 2001-2020

 ******************************************************************************
  �ļ���    ��db_table_main.h
  ����      �����Ӹ�
  ��������   ��2013-5-17
  ��������   :
             ��һ��ָ�������ݿ��ϣ�����һ������������Ϣ�ı�

  �����б�   :
  �޸���ʷ   :

******************************************************************************/
#ifndef __DB_TABLE_MAIN_H__
#define __DB_TABLE_MAIN_H__

#include "protocol.h"
//#include "sqlite3.h"
#include "./sqlite_lib/include/sqlite3.h"

#define	NTOS_TABLE_SYSINFO		 "sysinfo"
#define	NTOS_DB_FILE			 "ntos-config.db"
/* col name */
#define TABLE_MAIN_COL_KEY       "name"
#define TABLE_MAIN_COL_VALUE     "value"
/*name*/
#define SQLITE_NAME_DEV_NAME     "dev_name"
#define SQLITE_NAME_DEVICE_ID    "dev_id"
#define SQLITE_NAME_VERSION      "soft_version"
//serial name
#define SQLITE_NAME_SERIAL_1     "serial_1"
#define SQLITE_NAME_SERIAL_2     "serial_2"
#define SQLITE_NAME_SERIAL_3     "serial_3"
#define SQLITE_NAME_SERIAL_4     "serial_4"
//baud rate
#define SQLITE_NAME_RATE_1       "rate_1"
#define SQLITE_NAME_RATE_2       "rate_2"
#define SQLITE_NAME_RATE_3       "rate_3"
#define SQLITE_NAME_RATE_4       "rate_4"
//data bit
#define SQLITE_NAME_DATA_1       "data_1"
#define SQLITE_NAME_DATA_2       "data_2"
#define SQLITE_NAME_DATA_3       "data_3"
#define SQLITE_NAME_DATA_4       "data_4"
//stop bit
#define SQLITE_NAME_STOP_1       "stop_1"
#define SQLITE_NAME_STOP_2       "stop_2"
#define SQLITE_NAME_STOP_3       "stop_3"
#define SQLITE_NAME_STOP_4       "stop_4"
//parity bit
#define SQLITE_NAME_PARITY_1     "parity_1"
#define SQLITE_NAME_PARITY_2     "parity_2"
#define SQLITE_NAME_PARITY_3     "parity_3"
#define SQLITE_NAME_PARITY_4     "parity_4"
//work mode  client | server | register
#define SQLITE_NAME_WORK_MODE    "workMod"
#define SQLITE_NAME_IP           "ip"
#define SQLITE_NAME_MASK         "subnetMask"
//server port
#define SQLITE_NAME_SERPORT_1    "serPort1"
#define SQLITE_NAME_SERPORT_2    "serPort2"
#define SQLITE_NAME_SERPORT_3    "serPort3"
#define SQLITE_NAME_SERPORT_4    "serPort4"
#define SQLITE_NAME_GATEWAY      "gateWay"
//register server information
#define SQLITE_NAME_REG_IP       "regipstr"
#define SQLITE_NAME_REGPORT      "regport"
//password
#define SQLITE_NAME_PASSWD       "passwd"


//#include "config_info.h"

struct __db_table_main_rec
{
	char key_name[100];
	char value[100];
};
struct __db_table_cfg_value_init {
	char key_name[256];
	char  value[256];
};
typedef struct __db_table_cfg_value_init db_config_t;

extern sqlite3 *g_dbConfig;
extern struct __db_table_main_rec db_table_main_rec;
extern struct __db_table_cfg_value_init db_table_cfg_value_init[];

int db_table_main_load(sqlite3 *db, const char *tab_name);
char* get_datastr(struct __db_table_cfg_value_init *data, char *key, char *buf);

int get_sqlite_net(net_t *netdp);
int get_sqlite_serial(int serno, serial_t *serdata);
int get_sqlite_passwd(char *passwd);
int get_sqlite_sysinfo(sysInfo_t *sysinfo);
int modify_table_value(sqlite3* sqlite, const char *name, char *value);
int save_db_serial(int serno, serial_t serdata);
int save_db_netdata(net_t netd);
int save_db_passwd(char *pwd);

/*
extern int db_table_main_create(sqlite3 *db, const char *tab_name);
extern int db_table_main_load(sqlite3 *db, const char *tab_name);
extern int db_table_main_update(sqlite3 *db, const char *tab_name, const char *key_name, const char *value);
extern int db_table_main_update_old(sqlite3 *db, const char *tab_name, const char *key_name, const char *value);

extern const char *db_table_main_get(const char *key_name);
extern int db_table_main_get_cfg_info_string(char *cfg_string, int size);
*/
//extern int db_table_main_modify_cfg_info_all(char *cfg_string, int size);

#endif /* __DB_TABLE_MAIN_H__ */
