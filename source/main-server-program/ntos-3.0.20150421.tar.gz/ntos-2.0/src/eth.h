
/*-------------------------------------------------------------------------*/
/**
   @file    eth.h
   @author  g.m
*/
/*--------------------------------------------------------------------------*/
#ifndef __ETH_H__
#define __ETH_H__

/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include "protocol.h"
//#include "op_conf.h"


/*---------------------------------------------------------------------------
                            Function prototypes
 ---------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*/
/**
 */
/*--------------------------------------------------------------------------*/
/*  ipv4, stream, ip_reuse  */
//创建套結字
int create_socket();

/*--------------------------------------------------------------------------*/
void close_sockfd(int fd);						   //关閉套結字

/*--------------------------------------------------------------------------*/
int my_listen(int sockfd, int backlog);			   //监听连接 

/*--------------------------------------------------------------------------*/
int write_socket(int fd, void *src, int l);	   //写入套结字

/*--------------------------------------------------------------------------*/
int read_socket(int sockfd, void *des, int len); //读取套結字

/*--------------------------------------------------------------------------*/
void init_sockaddr_in(int sa, char *ipstr, int portnum, struct sockaddr_in *addr);

/*--------------------------------------------------------------------------*/
int bind_v4(int sockfd, struct sockaddr_in *laddr, socklen_t addrlen);   //绑定套结字

/*--------------------------------------------------------------------------*/
int my_accept(int sockfd, struct sockaddr_in *addr, unsigned int addrlen);//接受连接

/*--------------------------------------------------------------------------*/
int ip_change(char *dev, char *ip);
int SetLocalNetMask(const char *szNetMask);


#endif	/* __ETH_H__ */

