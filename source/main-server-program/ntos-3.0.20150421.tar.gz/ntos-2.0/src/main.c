/*--------------------------------------------------------------------------------------------*/
/*
 * 平台: arm处理器 Linux操作系统
 * 功能: 实現网口和串口数据的互相转发
 * 文件: netclient.c
 * 日期: 2014-7-21
 */
/*--------------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>  
#include "protocol.h"
#include "handle.h"

int main()
{
	if(server_init() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: server_init failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	if(server_start() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: server_start failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	if(server_uninit() != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: server_start failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	exit(SUCCESS);
}//main end

