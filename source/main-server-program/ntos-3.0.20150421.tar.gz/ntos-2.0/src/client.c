/*
 * file: netserver.c
 * date: 2014-7-21
 *
 * PC端测试程序
 * */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "ethl.h"

#define PORT			5057	//网络链接端口号
#define		BUFSIZE				1024		//数据缓冲区大小

typedef struct _edata_t {
	int serial;							//串口号:0 1 2 3 ...
	char data[BUFSIZE];					//数据内容 
}edata_t;


static void new_task(int sockfd);
static void *init_data_send(edata_t *send_buf);
static int socket_send(int sockfd, char *send_buf);
static int recv_from_net_print();

int sockfd;
void * mhandler(int t)
{
	close(sockfd);
	exit(0);
}

/***************    start    ******************/
int main(int argc, char **argv)
{
	if(argc != 3) {
		fprintf(stdout, "Usage: pc port ip\r\n");	
		exit(-1);
	}

	if((sockfd = connect_plx(argv[2], atoi(argv[1]) ) ) < 0) {
		fprintf(stdout, "connect_plx \r\n");	
		exit(-1);
	}

	printf("connect OK\n");
	new_task(sockfd);

	close_socket(sockfd);
	exit(0);
}
/***************    end start    ******************/

//任务处理
static void new_task(int sockfd)
{	
	edata_t send_buf;
	int i;

	pid_t pid;
	for(i = 0; i < 2; i++) {
		pid = fork();
		if(pid < 0) {
			perror("fork:");
			exit(-1);

		} else if (pid == 0) {
			//子进程
			if(i == 0) {
				//获取命令,发送命令
				int ret;
				while(1) {
					if(init_data_send(&send_buf) == NULL) {
						fprintf(stdout, "init_data_send() failed\r\n");
						continue;
					}
					if((ret = socket_send(sockfd, send_buf.data)) < 0) {
						fprintf(stdout, "socket_send() failed: %d\r\n", ret);
						continue;
					}
				}
			}
			if(i == 1) {
				//signal(SIGINT, mhandler(0));
				recv_from_net_print(sockfd);
			}
		}
	}

	for(i = 0; i < 2; i++)
		wait(NULL);

}
static char itoch(int num, char *ch)
{
	if(num < 0 || num > 3)
		return -1;
	if (ch == NULL)
		return -1;
	switch(num)
	{
		case 0:
			return *ch = '0';
		case 1:
			return *ch = '1';
		case 2:
			return *ch = '2';
		case 3:
			return *ch = '3';
		default:
			return -1;
	}
	return -1;
}
static void * init_data_send(edata_t *send_buf)
{
	if(send_buf == NULL)
		return NULL;
	memset(send_buf, '\0', BUFSIZE);
	send_buf->serial = -1;
	/*         填充需要发送的数据      */
	//接收 命令字符串 串口号
	fprintf(stdout, "comm serialNum:\n");
	scanf("%s %d", send_buf->data + 1, &(send_buf->serial));
	if(send_buf->serial < 0 || send_buf->serial > 4) {
		fprintf(stdout, "invalid serial number\r\n");
		return NULL;
	}
	if(itoch(send_buf->serial, send_buf->data) < 0) {
		fprintf(stdout, "invalid serial data\r\n");
		return NULL;
	}	

	return (void*)1;
}

static int socket_send(int sockfd, char *buf)
{
	/*将数据写套结字*/
	if(sockfd < 0)
		return -1;
	if(buf == NULL)
		return -2;
	if(strlen(buf) <= 0)
		return -3;
	
	printf("%s\r\n", buf);
	if(write_socket(sockfd, buf, strlen(buf)) < 0) {
		return -4;
	}

	return strlen(buf);
}

static int recv_from_net_print(int sockfd)
{
	edata_t buf;

	while(1)
	{
		memset(&buf, '\0', BUFSIZE);
		if(read_socket(sockfd, (void*)&buf, sizeof(buf)) <= 0)
			continue;
		printf("command: %s  serial: %d\r\n", buf.data, buf.serial); 
	}
	return 0;
}
