/*-------------------------------------------------------------------------*/
/**
   @file    serial.c
   @author  g.m
   @brief   串口操作相关函数
*/
/*--------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
                                Includes
 ---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdarg.h>
#include <errno.h>
//#include "log.h"
#include "serial.h"
#include "protocol.h"
#include "fun_exec.h"

/*---------------------------------------------------------------------------
                            Function codes
 ---------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*/
/**
  @brief    恢复控制台
  @param    fd	已打开的串口文件描述符
  @return   成功：0； 失败：-1
 */
/*--------------------------------------------------------------------------*/
static int internal_restore_console(int fd)
{
	if(fd < 0) {
		//to_log("%s failed", __FUNCTION__);
		fprintf(stdout, "%s %s() line:%d: parameter error\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	//恢复默认串口console
	if(ioctl(fd, TIOCCONS) != 0) {
		fprintf(stdout, "%s %s() line:%d: %s\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	return SUCCESS;
}

int reset_console(int fd)
{
	if(fd < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter is error.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	if(internal_restore_console(fd) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d: restore console failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	return SUCCESS;
}

/*-------------------------------------------------------------------------*/
/**
  @brief    把控制台转移到tty1
  @param    serial	串口设备文件路徑
  @return   成功: 0; 失败：-1
 */
/*--------------------------------------------------------------------------*/
int reset_console_tty(char *serial)
{
	if(serial == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	int fd_tty;

	if((fd_tty = open(serial, O_RDONLY)) < 0) {
		//to_log("open /dev/tty1 failed");
		fprintf(stdout, "%s %s() line:%d: %s\r\n", \
				__FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return EFAILED;
	}

	if(reset_console(fd_tty) != SUCCESS) {
		fprintf(stdout, "%s %s() line:%d\r\n", __FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	close(fd_tty);
	return SUCCESS;
}

/*-------------------------------------------------------------------------*/
/**
  @brief    配置串口参数
  @param    fd串口描述符;nSpeed波特率:nBits数据位:nEvent校验位:nStop停止位
  @return   成功：0； 失败：-1
 */
/*--------------------------------------------------------------------------*/
int internal_serial_config(int fd, int nSpeed, int nBits, char nEvent, int nStop)
{
    struct  termios new_ios,old_ios;

    if ( tcgetattr ( fd , &new_ios ) !=0 ) {
		fprintf(stdout, "%s %s() line:%d: get console attribuate failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

    bzero( &old_ios , sizeof( struct termios ));
    old_ios=new_ios;

    tcflush(fd,TCIOFLUSH) ;
    new_ios.c_cflag |= CLOCAL |CREAD ;
    new_ios.c_cflag &= ~CSIZE ;

    switch (nBits)
    {
        case 5:
            new_ios.c_cflag |=CS5 ;
            break ;
        case 6:
            new_ios.c_cflag |=CS6 ;
            break ;
        case 7:
            new_ios.c_cflag |=CS7 ;
            break ;
        case 8:
            new_ios.c_cflag |=CS8 ;
            break ;
        default:
			return EFAILED;
    }
    switch (nSpeed )
    {
        case 2400:
            cfsetispeed(&new_ios , B2400);
            cfsetospeed(&new_ios , B2400);
            break;
        case 4800:
            cfsetispeed(&new_ios , B4800);
            cfsetospeed(&new_ios , B4800);
            break;
        case 9600:
            cfsetispeed(&new_ios , B9600);
            cfsetospeed(&new_ios , B9600);
            break;
        case 19200:
            cfsetispeed(&new_ios , B19200);
            cfsetospeed(&new_ios , B19200);
            break;
        case 115200:
            cfsetispeed(&new_ios , B115200);
            cfsetospeed(&new_ios , B115200);
            break;
        case 460800:
            cfsetispeed(&new_ios , B460800);
            cfsetospeed(&new_ios , B460800);
            break;
        default:
			return EFAILED;
    }
    switch (nEvent )
    {
        case 'o':
        case 'O':
            new_ios.c_cflag |= PARENB ;
            new_ios.c_cflag |= PARODD ;
            new_ios.c_iflag |= (INPCK | ISTRIP);
            break ;
        case 'e':
        case 'E':
            new_ios.c_iflag |= (INPCK | ISTRIP);
            new_ios.c_cflag |= PARENB ;
            new_ios.c_cflag &= ~PARODD ;
            break ;
        case 'n':
        case 'N':
            new_ios.c_cflag &= ~PARENB ;
            new_ios.c_iflag &= ~INPCK  ;
            break ;
        default:
			return EFAILED;
    }
    if ( nStop == 1 )
        new_ios.c_cflag &= ~CSTOPB ;
    else if ( nStop == 2 )
        new_ios.c_cflag |= CSTOPB ;

    /*No hardware control*/
    new_ios.c_cflag &= ~CRTSCTS;
    /*No software control*/
    new_ios.c_iflag &= ~(IXON | IXOFF | IXANY);
    /*delay time set */
    //new_ios.c_cc[VTIME] = 0 ;
    //new_ios.c_cc[VMIN] = 0 ;

    /*raw model*/
    new_ios.c_lflag  &= ~(ICANON | ECHO | ECHOE | ISIG);
    new_ios.c_oflag  &= ~OPOST;

    new_ios.c_iflag &= ~(INLCR|IGNCR|ICRNL);
    new_ios.c_iflag &= ~(ONLCR|OCRNL);

    new_ios.c_oflag &= ~(INLCR|IGNCR|ICRNL);
    new_ios.c_oflag &= ~(ONLCR|OCRNL);

    tcflush(fd, TCIOFLUSH) ;
    if (tcsetattr(fd,TCSANOW,&new_ios) != 0 ) {
        tcsetattr(fd,TCSANOW,&old_ios);
		return EFAILED;
    }

    return  SUCCESS;
}


/*-------------------------------------------------------------------------*/
/**
  @brief    写串口,通过串口发送数据
  @param    fd 文件描述符；buffer 数据保存地址；data_len 数据长度
  @return   成功：0； 失败：-1
 */
/*--------------------------------------------------------------------------*/
int serial_write(int fd, const void *buffer, int data_len)
{
	int k, dist=0;
	int split = 1024;        /* 按1024分割 */

	if(buffer == NULL || data_len <= 0 || fd < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter error.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	for(k = 0; k < (data_len/split); ++k) {
		dist = k*split;
		if(write(fd, buffer + dist, split) < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			return EFAILED;
		}
	}

	if(data_len % split) {
		int len = data_len % split;
		if(data_len/split) dist += split;

		if(write(fd, buffer + dist, len) < 0) {
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			return EFAILED;
		}
	}
	return SUCCESS;
}

/*-------------------------------------------------------------------------*/
/**
  @brief    读串口，接收数据
  @param    fd 串口文件描述符；buffer 数据回填地址； size 数据长度
  @return   成功返回读到的字节数；失败：-1
 */
/*--------------------------------------------------------------------------*/
int serial_read(int fd, void *buffer, int size)
{
	int ret;

	if(buffer == NULL || size <= 0 || fd < 0) {
		fprintf(stdout, "%s %s() line:%d: parameter error.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	do {
		ret = read(fd, buffer, size);
		if(ret == EAGAIN)
			continue;
		else if(ret == EWOULDBLOCK)
			return 0;
		 else if(ret == 0) {
			return ret;
		} else if(ret < 0) {
			/*
			fprintf(stdout, "%s %s() line:%d: %s.\r\n", \
					__FILE__, __FUNCTION__, __LINE__, strerror(errno));
					*/
			return EFAILED;
		}

	} while(0);

	return ret;
}

//关闭已打开的串口
int serial_close(int fd)
{
	return close(fd);
}
//close all opend serial
int serial_close_all(int *fd)
{
	int i;
	for(i = 0; i < 4; i++) {
		if(serial_close(fd[i])) {
			fprintf(stdout, "%s %s() line:%d: parameter error.\r\n", \
					__FILE__, __FUNCTION__, __LINE__);
			return EFAILED;
		}
	}

	return SUCCESS;
}
/*-------------------------------------------------------------------------*/
/**
  @brief    以读写方式打开串口，并且当前程序不作为串口的控制程序
  @param    
  @return   成功返回一个文件描述符；失败返回0
 */
/*--------------------------------------------------------------------------*/
int internal_serial_open(char *serial, int speed, int bit, char event, int stop)
{
	int fd_tty;

	// |O_NONBLOCK 打开串口0读写
	//O_NOCTTY	program no console
	if((fd_tty = open(serial, O_RDWR|O_NOCTTY)) < 0) {
		fprintf(stdout, "%s %s() line:%d: %s %s.\r\n", \
				__FILE__, __FUNCTION__, __LINE__, serial, strerror(errno));
		return EFAILED;
	}

	//default config 
	if(internal_serial_config(fd_tty, speed, bit, event, stop) != SUCCESS) {
		//to_log("internal_serial_config failed");
		fprintf(stdout, "%s %s() line:%d: default config failed.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}
	return fd_tty;
}
/*-------------------------------------------------------------------------*/
/**
  @brief    打开串口，并且转移控制台值tty1,打开后默认配置为:115200 8 n 1
  @param    serial_d 串口设备文件路径
  @return   成功：文件描述符； 失败：-1
 */
/*--------------------------------------------------------------------------*/
int serial_open(char *serial_d)
{
	int fd_tty;

	if(serial_d == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter error.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	if((fd_tty = internal_serial_open(serial_d, 115200, 8, 'n', 1)) == EFAILED) {
		fprintf(stdout, "%s %s() line:%d:open serial failed\r\n", \
				__FILE__,__FUNCTION__, __LINE__);
		return EFAILED;
	}

	//to_log("serial port opened.\n");
	return fd_tty;
}
extern int
serial_open_all(char **serialdev, int *fd)
{
	int i; 

	if(serialdev == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter error.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}
	for(i = 0; i < 4; i++) {
		if((fd[i] = serial_open(serialdev[i])) < 0) {
			fprintf(stdout, "%s %s() line:%d:open serial '%s' failed\r\n", \
					__FILE__,__FUNCTION__, __LINE__, serialdev[i]);
			return EFAILED;
		}
	}

	return SUCCESS;
}

/*---------------------------------------------------------------------*/
/**
  @brief    根据指定串口号发送数据 
  @param    fd 串口文件描述符；data 数据地址； len 数据长度
  @return   void
 */
/*---------------------------------------------------------------------*/
int 
chose_serial_send(const int *seriafd, int fd, const void *data, int len)
{
	if(fd < 0 || data == NULL) {
		fprintf(stdout, "%s %s() line:%d: parameter is NULL.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EPARAMETER;
	}

	switch(fd) {
	case 0:
	case 1:
	case 2:
	case 3:
		serial_write(seriafd[fd], (void *)data, len); 
		break;
	default :
		fprintf(stdout, "%s %s() line:%d: invalid data.\r\n", \
				__FILE__, __FUNCTION__, __LINE__);
		return EFAILED;
	}

	return SUCCESS;
}




