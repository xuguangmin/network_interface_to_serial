#!/bin/sh

make clean

cd sqlite-autoconf-3080803
sqlite_build=`pwd`/../sqlite_lib
echo $sqlite_build
make clean
./configure --prefix=$sqlite_build --host=arm-linux CC=`which arm-linux-gcc`
make
make install
cd ../
make



