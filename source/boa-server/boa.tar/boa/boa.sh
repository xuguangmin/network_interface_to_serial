#!/bin/sh

echo "running boa.sh"
echo ""


if [ ! -d "var/log" ]; then
	mkdir /var/log
fi
if [ ! -d "var/log/boa" ]; then
	mkdir /var/log/boa
fi
if [ ! -f "var/log/boa/error_log" ]; then
	touch /var/log/boa/error_log
fi
if [ ! -f "var/log/boa/access_log" ]; then
	touch /var/log/boa/access_log
fi
