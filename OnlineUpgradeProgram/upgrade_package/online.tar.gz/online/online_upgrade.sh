#!/bin/sh

bootloader=u-boot.bin
kernel=zImage
rootfs=3.yaffs2_image_jikong_20150421.bin


echo "running online_upgrade.sh"

cd /upgrade/online/
if [ -f "$bootloader" ]; then
	echo "upgrading $bootloader"
	command/flash_eraseall		/dev/mtd0
	command/nandwrite	   -p	/dev/mtd0	$bootloader
else
	echo "don't have $bootloader, and skip to upgrade $bootloader"
fi

if [ -f "$kernel" ]; then
	echo "upgrading $kernel"
	command/flash_eraseall		/dev/mtd1
	command/nandwrite	   -p	/dev/mtd1	$kernel
else
	echo "don't have $kernel, and skip to upgrade $kernel"
fi


